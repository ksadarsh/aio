# Dracula for [GRUB](https://gnu.org/software/grub/)

> A dark theme for [GRUB](https://gnu.org/software/grub/).

![Screenshot](./screenshot.png)

## Install

All instructions can be found at [draculatheme.com/grub](https://draculatheme.com/grub).

## Team

This theme is maintained by the following person(s) and a bunch of [awesome contributors](https://github.com/dracula/grub/graphs/contributors).

[![Zeno Rocha](https://github.com/pspiagicw.png?size=100)](https://github.com/pspiagicw) |
--- |
[Zeno Rocha](https://github.com/pspiagicw) |

## License

[MIT License](./LICENSE)
